#ifndef EFF_H
#define EFF_H

#include "../../inc/config.h"

void efficiency(void);

#endif //EFF_H
