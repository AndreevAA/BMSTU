#include "../../inc/config.h"

int is_choose_build_simple_tree(int temp_menu_status);
int is_choose_build_balanced_tree(int temp_menu_status);
int is_choose_build_simple_ddt(int temp_menu_status);
int is_choose_build_balanced_ddt(int temp_menu_status);
int is_choose_build_hash_table(int temp_menu_status);
int is_choose_print_hash_table(int temp_menu_status);
int is_choose_search_number_in_hash_table(int temp_menu_status);
int is_choose_search_number_in_op_file(int temp_menu_status);
int is_choose_print_efficiency(int temp_menu_status);
int is_choose_exit(int temp_menu_status);
