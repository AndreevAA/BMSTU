#!/bin/bash

gcc -c src/efficiency/efficiency.c -o out/efficiency.o
gcc -c src/efficiency/get_time.c -o out/get_time.o

gcc -c src/main.c -o out/main.o  
gcc -c src/io.c -o out/io.o 

gcc -c src/menu/menu.c -o out/menu.o
gcc -c src/menu/checks.c -o out/checks.o
gcc -c src/menu/comps.c -o out/comps.o

gcc -c src/tree_operations/balance.c -o out/balance.o
gcc -c src/tree_operations/export.c -o out/export.o
gcc -c src/tree_operations/hash.c -o out/hash.o
gcc -c src/tree_operations/search.c -o out/search.o
gcc -c src/tree_operations/tree.c -o out/tree.o

gcc src/main.c src/io.c src/tree_operations/balance.c src/tree_operations/export.c src/tree_operations/hash.c src/efficiency/efficiency.c src/tree_operations/search.c src/tree_operations/tree.c src/menu/menu.c src/menu/comps.c src/menu/checks.c src/efficiency/get_time.c

