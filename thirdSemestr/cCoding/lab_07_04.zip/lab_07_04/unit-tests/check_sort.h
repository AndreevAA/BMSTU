#ifndef LAB_07_SORT_TESTS_H
#define LAB_07_SORT_TESTS_H

#include <stdlib.h>
#include <check.h>

Suite* sort_test_suite(void);

#endif //LAB_07_SORT_TESTS_H
