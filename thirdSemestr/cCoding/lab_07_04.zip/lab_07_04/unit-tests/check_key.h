#ifndef LAB_07_FILTER_TESTS_H
#define LAB_07_FILTER_TESTS_H

#include <stdlib.h>
#include <check.h>

Suite* key_test_suite(void);

#endif //LAB_07_FILTER_TESTS_H
