create function count_workers(date) returns integer
    language plpgsql
as
$$
begin
    return (
        select count(*) as cnt
        from (
            select worker_id, count(*) as cnt
            from schedule_io
            where date = $1 and type = 2
            group by worker_id
        ) as leave_cnt join worker as E on leave_cnt.worker_id = E.worker_id
        where extract(years from age(E.db)) between 18 and 40
        );
end;
$$;

alter function count_workers(date) owner to postgres;

