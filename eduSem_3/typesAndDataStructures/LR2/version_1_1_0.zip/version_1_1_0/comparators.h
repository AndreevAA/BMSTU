#include "menu.h"

int comp_double (const void *i, const void *j);
int average_score_per_session_cmp (const void *i, const void *j);
int house_or_campus_number_cmp (const void *i, const void *j);
int flat_or_room_number_cmp (const void *i, const void *j);
int age_cmp (const void *i, const void *j);
