#include "menu.h"

int is_right_argc(int argc);
int is_key_right(char *key);
int is_right_argv(int argc, char const *argv[]);
